CREATE DATABASE IF NOT EXISTS quizdb;
USE quizdb;

-- Users Table
CREATE TABLE IF NOT EXISTS users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  username VARCHAR(50) NOT NULL,
  email VARCHAR(100) NOT NULL UNIQUE,
  password VARCHAR(100) NOT NULL
);

INSERT INTO users (username, email, password) VALUES
('pratiksha', 'pratiksha@gmail.com', 'pratiksha123'),
('prachi', 'prachi@gmail.com', 'prachi123'),
('nilesh', 'nilesh@gmail.com', 'nilesh123'),
('manali', 'manali@gmail.com', 'manali123'),
('sanat', 'sanat@gmail.com', 'sanat123');

-- Questions Table
CREATE TABLE IF NOT EXISTS questions (
  id INT AUTO_INCREMENT PRIMARY KEY,
  question TEXT NOT NULL,
  option_a VARCHAR(255) NOT NULL,
  option_b VARCHAR(255) NOT NULL,
  option_c VARCHAR(255) NOT NULL,
  option_d VARCHAR(255) NOT NULL,
  correct_option ENUM('A', 'B', 'C', 'D') NOT NULL,
  subject VARCHAR(100) NOT NULL,
  timer INT DEFAULT 30
);

INSERT INTO questions (question, option_a, option_b, option_c, option_d, correct_option, subject, timer) VALUES
('What gas do plants absorb during photosynthesis?', 'Oxygen', 'Carbon Dioxide', 'Nitrogen', 'Hydrogen', 'B', 'Science', 30),
('What is the chemical symbol for water?', 'HO', 'O2', 'H2O', 'OH2', 'C', 'Science', 30),
('Which part of the cell contains DNA?', 'Mitochondria', 'Ribosome', 'Nucleus', 'Cytoplasm', 'C', 'Science', 30),
('Which planet is known as the Red Planet?', 'Earth', 'Mars', 'Jupiter', 'Venus', 'B', 'Science', 30),
('What is the boiling point of water at sea level?', '90°C', '100°C', '110°C', '120°C', 'B', 'Science', 30),
('Which vitamin is produced when a person is exposed to sunlight?', 'Vitamin A', 'Vitamin B', 'Vitamin C', 'Vitamin D', 'D', 'Science', 30),
('What is the powerhouse of the cell?', 'Nucleus', 'Ribosome', 'Mitochondria', 'Golgi Body', 'C', 'Science', 30),
('Which organ is responsible for pumping blood?', 'Liver', 'Brain', 'Heart', 'Lungs', 'C', 'Science', 30),
('What is the most abundant gas in Earths atmosphere?', 'Oxygen', 'Carbon Dioxide', 'Nitrogen', 'Hydrogen', 'C', 'Science', 30),
('Which of these is a renewable source of energy?', 'Coal', 'Oil', 'Natural Gas', 'Solar Energy', 'D', 'Science', 30);



-- Results Table
CREATE TABLE IF NOT EXISTS results (
  id INT AUTO_INCREMENT PRIMARY KEY,
  user_id INT NOT NULL,
  score INT NOT NULL,
  total_questions INT NOT NULL,
  subject VARCHAR(100),
  submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

select * from users;
select * from questions;
select * from results;