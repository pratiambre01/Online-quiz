const express = require('express');
const mysql = require('mysql2');
const path = require('path');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

// MySQL Connection
const db = mysql.createConnection({
  host: '127.0.0.1',
  user: 'root',
  password: '', // your MySQL password
  database: 'quizdb' // your DB name
});

db.connect(err => {
  if (err) throw err;
  console.log('Connected to MySQL Database');
});

// Serve HTML Pages
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public/index.html')));
app.get('/login', (req, res) => res.sendFile(path.join(__dirname, 'public/login.html')));
app.get('/register', (req, res) => res.sendFile(path.join(__dirname, 'public/register.html')));
app.get('/quiz', (req, res) => res.sendFile(path.join(__dirname, 'public/quiz.html')));
app.get('/result', (req, res) => res.sendFile(path.join(__dirname, 'public/result.html')));
app.get('/dashboard', (req, res) => res.sendFile(path.join(__dirname, 'public/dashboard.html')));
app.get('/admin', (req, res) => res.sendFile(path.join(__dirname, 'public/admin.html')));

// User Registration
app.post('/register', (req, res) => {
  const { username, email, password } = req.body;
  const checkUser = `SELECT * FROM users WHERE username = ?`;
  db.query(checkUser, [username], (err, results) => {
    if (err) return res.status(500).send('Database error');
    if (results.length > 0) return res.status(400).send('User already exists');
    const sql = `INSERT INTO users (username, email, password) VALUES (?, ?, ?)`;
    db.query(sql, [username, email, password], err => {
      if (err) return res.status(500).send('Error saving user');
      console.log('Registered user:', { username, email }); // <-- Add this line

      res.send('User registered successfully');
    });
  });
});

// User Login
app.post('/api/login', (req, res) => {
  const { username, password } = req.body;

  // Admin Check
  if (username === 'admin' && password === 'admin@123') {
    return res.json({ success: true, role: 'admin' });
  }

  const sql = `SELECT * FROM users WHERE username = ? AND password = ?`;
  db.query(sql, [username, password], (err, results) => {
    if (err) return res.status(500).send('Database error');

    if (results.length === 0) {
      return res.json({ success: false, message: 'Invalid username or password' });
    }

    // This is the line you asked about:
    res.json({ success: true, role: 'user', user: results[0] });
  });
});


// Fetch Quiz Questions
app.get('/api/questions', (req, res) => {
  const sql = 'SELECT id, question, option_a, option_b, option_c, option_d, correct_option, subject, timer FROM questions';
  db.query(sql, (err, results) => {
    if (err) return res.status(500).send('Error fetching questions');
    res.json(results);
  });
});

// Save Quiz Result
app.post('/api/submit-quiz', (req, res) => {
  const { user_id, score, total_questions, subject } = req.body;
  const sql = 'INSERT INTO results (user_id, score, total_questions, subject) VALUES (?, ?, ?, ?)';
  db.query(sql, [user_id, score, total_questions, subject], err => {
    if (err) return res.status(500).send('Error saving result');
    res.send('Result saved successfully');
  });
});

// Get Result for Display
app.get('/api/results/:userId', (req, res) => {
  const { userId } = req.params;
  const sql = 'SELECT * FROM results WHERE user_id = ? ORDER BY id DESC LIMIT 1';
  db.query(sql, [userId], (err, results) => {
    if (err) return res.status(500).send('Error retrieving result');
    res.json(results[0]);
  });
});

// Add Question
app.post('/api/questions', (req, res) => {
  const { question, option_a, option_b, option_c, option_d, correct_option, subject, timer } = req.body;
  const sql = 'INSERT INTO questions (question, option_a, option_b, option_c, option_d, correct_option, subject, timer) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
  db.query(sql, [question, option_a, option_b, option_c, option_d, correct_option, subject, timer], err => {
    if (err) return res.status(500).send('Error adding question');
    res.send('Question added successfully');
  });
});

// Edit Question
app.put('/api/questions/:id', (req, res) => {
  const { id } = req.params;
  const { question, option_a, option_b, option_c, option_d, correct_option, subject, timer } = req.body;
  const sql = 'UPDATE questions SET question=?, option_a=?, option_b=?, option_c=?, option_d=?, correct_option=?, subject=?, timer=? WHERE id=?';
  db.query(sql, [question, option_a, option_b, option_c, option_d, correct_option, subject, timer, id], err => {
    if (err) return res.status(500).send('Error updating question');
    res.send('Question updated successfully');
  });
});

// Delete Question
app.delete('/api/questions/:id', (req, res) => {
  const { id } = req.params;
  const sql = 'DELETE FROM questions WHERE id = ?';
  db.query(sql, [id], err => {
    if (err) return res.status(500).send('Error deleting question');
    res.send('Question deleted successfully');
  });
});

// Start Server
app.listen(PORT, () => {
  console.log(`Server running at http://localhost:${PORT}`);
});
